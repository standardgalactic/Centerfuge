
# Appendix E — Deployment & Provenance
Dockerfile included (Ubuntu + Blender). Each still writes a JSON sidecar
with scene name, seed, size. For clusters: run the shell runner per job.
