
# Eloi vs. Morlocks — Vector Simulation Suite (Flyxion)
Vector-aesthetic stills rendered headlessly in Blender, encoding RSVP
semantics: Eloi (diffusive, open equilibrium) vs Morlocks (confined,
negentropic). See Appendices for color grammar and reproducibility notes.

**Render all stills**
```bash
bash run_eloi_morlock_stills.sh
```
