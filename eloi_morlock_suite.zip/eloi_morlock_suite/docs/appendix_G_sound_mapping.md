
# Appendix G — Sound Mapping
Pitch f(phi)=220*2^phi, amplitude=0.5(1+phi). Eloi=Lydian; Morlocks=Phrygian.
