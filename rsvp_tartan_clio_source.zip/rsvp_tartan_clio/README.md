# RSVP–TARTAN–CLIO Experimental Architecture and Roadmap

This repo contains a headless pipeline for generating Blender-based experiments, running Python operators,
and automating execution via shell scripts.

## Quick Start
```bash
# 1) Ensure Blender is installed on your system
# 2) Set up Python environment
./automation/environment_setup.sh

# 3) Run the full pipeline (generates experiments + runs operators)
./automation/run_all.sh
```

## Structure
- `bpy_scripts/` – Blender scripts (`generate_experiment.py`, `simulate_entropy_field.py`, `render_snapshot.py`)
- `python_ops/` – Operators library and CLI dispatcher
- `experiments/Tier_*` – Output directories
- `logs/analysis` – Operator outputs
- `automation/` – Shell scripts and cron schedule
