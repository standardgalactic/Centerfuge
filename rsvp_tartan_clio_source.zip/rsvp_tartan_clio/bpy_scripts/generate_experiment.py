#!/usr/bin/env python3
# Headless Blender experiment generator for RSVP–TARTAN–CLIO corpus
# Creates a torus grid, computes proxy entropy+curvature, and exports logs + OBJ + PNG.
# Usage:
#   blender -b -P bpy_scripts/generate_experiment.py -- --name exp_entropy_cascade --tier Tier_I --frames 120

import bpy, bmesh, sys, argparse, json, random
from pathlib import Path

def parse_args():
    argv = sys.argv
    if "--" in argv: argv = argv[argv.index("--") + 1:]
    p = argparse.ArgumentParser()
    p.add_argument("--name", required=True, help="experiment name (folder)")
    p.add_argument("--tier", default="Tier_I")
    p.add_argument("--frames", type=int, default=60)
    p.add_argument("--seed", type=int, default=1337)
    p.add_argument("--subdiv", type=int, default=3, help="subdivisions per torus")
    return p.parse_args(argv)

def ensure_dir(p: Path): p.mkdir(parents=True, exist_ok=True)

def create_torus_grid(rows=2, cols=2, radius=1.2, tube=0.35, spacing=3.0):
    tori = []
    for r in range(rows):
        for c in range(cols):
            bpy.ops.mesh.primitive_torus_add(major_radius=radius, minor_radius=tube)
            obj = bpy.context.active_object
            obj.location = (c * spacing, r * spacing, 0.0)
            tori.append(obj)
    ctx = bpy.context.copy()
    ctx["active_object"] = tori[0]
    ctx["selected_editable_objects"] = tori
    bpy.ops.object.join(ctx)
    return tori[0]

def subdivide(obj, levels=2):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.modifier_add(type='SUBSURF')
    obj.modifiers["Subdivision"].levels = levels
    bpy.ops.object.modifier_apply(modifier="Subdivision")

def compute_entropy_and_curvature(obj):
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    neighbors = {v.index: set() for v in bm.verts}
    for e in bm.edges:
        a, b = e.verts[0].index, e.verts[1].index
        neighbors[a].add(b); neighbors[b].add(a)
    import random
    entropy, curvature = {}, {}
    for v in bm.verts:
        entropy[v.index] = random.random()
    for v in bm.verts:
        ns = neighbors[v.index]
        if not ns:
            curvature[v.index] = 0.0
        else:
            avg = sum(entropy[n] for n in ns) / len(ns)
            curvature[v.index] = abs(entropy[v.index] - avg)
    bm.free()
    return entropy, curvature

def export_obj(obj, out_path: Path):
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.export_scene.obj(filepath=str(out_path), use_selection=True, use_materials=False)

def configure_render(exp_dir: Path):
    scn = bpy.context.scene
    scn.render.engine = 'BLENDER_EEVEE'
    scn.render.image_settings.file_format = 'PNG'
    scn.render.resolution_x = 1600
    scn.render.resolution_y = 1200
    scn.render.filepath = str(exp_dir / "snapshot.png")

def main():
    args = parse_args()
    random.seed(args.seed)
    exp_dir = Path("experiments") / args.tier / args.name
    ensure_dir(exp_dir)

    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.object.camera_add(location=(6, -8, 6))
    bpy.context.scene.camera = bpy.context.active_object
    bpy.ops.object.light_add(type='SUN', location=(10, 10, 10))

    obj = create_torus_grid()
    subdivide(obj, levels=args.subdiv)

    entropy, curvature = compute_entropy_and_curvature(obj)
    (exp_dir / "metrics.json").write_text(json.dumps({"tier": args.tier, "verts": len(obj.data.vertices)}, indent=2))
    (exp_dir / "entropy.json").write_text(json.dumps(entropy, indent=2))
    (exp_dir / "curvature.json").write_text(json.dumps(curvature, indent=2))

    export_obj(obj, exp_dir / "mesh.obj")
    configure_render(exp_dir)
    bpy.ops.render.render(write_still=True)
    print(f"[✓] Generated {args.name} in {exp_dir}")

if __name__ == "__main__":
    main()
