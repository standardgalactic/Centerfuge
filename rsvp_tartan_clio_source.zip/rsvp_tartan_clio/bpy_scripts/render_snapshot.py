#!/usr/bin/env python3
# Import OBJ and render PNG using a fixed camera/light rig.
import bpy, sys
from pathlib import Path

def setup_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.object.camera_add(location=(6, -8, 6))
    bpy.ops.object.light_add(type='SUN', location=(10, 10, 10))
    bpy.context.scene.camera = bpy.context.active_object
    bpy.context.scene.render.engine = 'BLENDER_EEVEE'
    bpy.context.scene.render.resolution_x = 1600
    bpy.context.scene.render.resolution_y = 1200

def main():
    argv = sys.argv
    if "--" in argv: argv = argv[argv.index("--")+1:]
    obj_path = Path(argv[0])
    out_png = Path(argv[1]) if len(argv) > 1 else obj_path.with_suffix(".png")
    setup_scene()
    bpy.ops.import_scene.obj(filepath=str(obj_path))
    bpy.context.scene.render.filepath = str(out_png)
    bpy.ops.render.render(write_still=True)
    print(f"[✓] Rendered {out_png}")

if __name__ == "__main__":
    main()
