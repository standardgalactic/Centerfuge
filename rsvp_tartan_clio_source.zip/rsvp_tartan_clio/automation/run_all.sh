#!/usr/bin/env bash
# Orchestrate generation + analysis in one pass.
set -euo pipefail

# Generate sample experiments
blender -b -P bpy_scripts/generate_experiment.py -- --name exp_entropy_cascade --tier Tier_I --frames 120
blender -b -P bpy_scripts/generate_experiment.py -- --name exp_flow_crystal     --tier Tier_II --frames 120
blender -b -P bpy_scripts/generate_experiment.py -- --name exp_semantic_weave   --tier Tier_III --frames 120

# Optional time series
blender -b -P bpy_scripts/simulate_entropy_field.py

# Run operators
python python_ops/orchestrator.py --op entropy_curvature_correlation --glob "experiments/Tier_I/*" --out logs/analysis/tier1_corr.json
python python_ops/orchestrator.py --op drift_phase_coherence        --glob "experiments/Tier_II/*" --out logs/analysis/tier2_plv.json
python python_ops/orchestrator.py --op drift_phase_coherence        --glob "experiments/Tier_III/*" --out logs/analysis/tier3_plv.json

echo "[✓] Full pipeline complete."
