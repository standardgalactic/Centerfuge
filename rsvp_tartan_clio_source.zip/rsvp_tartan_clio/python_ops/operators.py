#!/usr/bin/env python3
"""Analytic / merging / recursive operators over experiment directories."""
import json, numpy as np
from pathlib import Path
from typing import List, Dict

def _load_json(p: Path, default=None):
    try:
        with open(p, "r") as f: return json.load(f)
    except FileNotFoundError:
        return {} if default is None else default

def entropy_curvature_correlation(exp_dirs: List[str]) -> Dict:
    corrs = []
    for d in exp_dirs:
        d = Path(d)
        e = _load_json(d / "entropy.json")
        k = _load_json(d / "curvature.json")
        keys = sorted(set(e) & set(k))
        if not keys: continue
        x = np.array([e[i] for i in keys], dtype=float)
        y = np.array([k[i] for i in keys], dtype=float)
        if len(x) > 1 and np.std(x) > 0 and np.std(y) > 0:
            corrs.append(float(np.corrcoef(x, y)[0, 1]))
    return {"count": len(corrs), "mean_corr": float(np.mean(corrs)) if corrs else None}

def drift_phase_coherence(exp_dirs: List[str]) -> Dict:
    def plv(phases):
        phases = np.array(phases)
        return float(np.abs(np.mean(np.exp(1j*phases))))

    plvs = []
    for d in exp_dirs:
        d = Path(d)
        series = _load_json(d / "entropy_series.json")
        phases = series.get("mean_entropy", [])
        if len(phases) > 5:
            s = (np.array(phases) - np.mean(phases)) / (np.std(phases) + 1e-8)
            theta = np.pi * np.tanh(s)
            plvs.append(plv(theta))
    return {"count": len(plvs), "mean_plv": float(np.mean(plvs)) if plvs else None}

def veil_visibility_optimizer(exp_dirs: List[str]) -> Dict:
    results = {}
    for d in exp_dirs:
        best_alpha = 0.42  # placeholder
        info_gain = 0.18
        results[str(d)] = {"alpha": best_alpha, "info_gain": info_gain}
    return {"experiments": results}

def run_registry(op_name: str, exp_dirs: List[str]) -> Dict:
    registry = {
        "entropy_curvature_correlation": entropy_curvature_correlation,
        "drift_phase_coherence": drift_phase_coherence,
        "veil_visibility_optimizer": veil_visibility_optimizer
    }
    func = registry.get(op_name)
    if not func:
        raise SystemExit(f"Unknown operator: {op_name}")
    return func(exp_dirs)
