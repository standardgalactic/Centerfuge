#!/usr/bin/env python3
# CLI dispatcher to run operators over experiment directories.
import argparse, glob, json
from pathlib import Path
from operators import run_registry

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--op", required=True, help="operator name")
    ap.add_argument("--glob", default="experiments/Tier_I/*", help="glob for experiment directories")
    ap.add_argument("--out", default="logs/analysis/result.json", help="output JSON file")
    args = ap.parse_args()

    exp_dirs = [p for p in glob.glob(args.glob) if Path(p).is_dir()]
    result = run_registry(args.op, exp_dirs)

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    with open(args.out, "w") as f: json.dump(result, f, indent=2)
    print(f"[✓] {args.op} → {args.out}")

if __name__ == "__main__":
    main()
