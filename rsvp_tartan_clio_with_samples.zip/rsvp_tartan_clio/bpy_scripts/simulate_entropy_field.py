#!/usr/bin/env python3
# Simulate scalar entropy time series with diffusion + noise; outputs JSON.
import bpy, json, random
from pathlib import Path

FRAMES = 100
ALPHA = 0.92
NOISE = 0.08

def ensure_dir(p: Path): p.mkdir(parents=True, exist_ok=True)

def init_scene():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.object.camera_add(location=(6, -8, 6))
    bpy.ops.object.light_add(type='SUN', location=(10, 10, 10))
    bpy.context.scene.camera = bpy.context.active_object

def torus_grid(rows=2, cols=2):
    objs = []
    for r in range(rows):
        for c in range(cols):
            bpy.ops.mesh.primitive_torus_add(major_radius=1.2, minor_radius=0.35)
            o = bpy.context.active_object
            o.location = (c * 3.0, r * 3.0, 0.0)
            objs.append(o)
    ctx = bpy.context.copy()
    ctx["active_object"] = objs[0]
    ctx["selected_editable_objects"] = objs
    bpy.ops.object.join(ctx)
    return objs[0]

def simulate_entropy(obj, frames=FRAMES, alpha=ALPHA, noise=NOISE):
    mesh = obj.data
    n = len(mesh.vertices)
    s = [random.random() for _ in range(n)]
    series = []
    for _ in range(frames):
        s2 = []
        for i in range(n):
            left = s[i-1] if i > 0 else s[i]
            right = s[i+1] if i < n-1 else s[i]
            avg = 0.5*(left+right)
            val = alpha*s[i] + (1-alpha)*avg + noise*(random.random()-0.5)
            s2.append(max(0.0, min(1.0, val)))
        s = s2
        series.append(sum(s)/n)
    return series

def main():
    out_dir = Path("experiments/Tier_II/exp_entropy_flow")
    ensure_dir(out_dir)
    init_scene()
    obj = torus_grid()
    series = simulate_entropy(obj)
    (out_dir / "entropy_series.json").write_text(json.dumps({"mean_entropy": series}, indent=2))
    print(f"[✓] Simulated entropy series → {out_dir}")

if __name__ == "__main__":
    main()
