#!/usr/bin/env bash
# environment_setup.sh — install Python deps (NumPy/Pandas). Blender install is system-specific.
set -euo pipefail
python3 - <<'PY'
import sys, subprocess
for pkg in ["numpy", "pandas"]:
    try:
        __import__(pkg)
        print(f"[✓] {pkg} present")
    except ImportError:
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
print("[✓] Python environment ready.")
PY
